import React, { useState } from "react";
import { LayoutDashboard, Bot, LogOut, Wrench, AlertTriangle, ClipboardList, Package, CalendarClock } from "lucide-react";
import { useAuth } from "../lib/auth";
import { useVesselContext } from "../lib/vessel-context";
import { CopilotContextProvider } from "../lib/copilot-context";
import { MobileCopilot } from "./MobileCopilot";
import { CmsLogo } from "./CmsLogo";
import { MobileDashboard } from "../mobile/MobileDashboard";
import { MobileWorkOrders, type WoFilter } from "../mobile/MobileWorkOrders";
import { MobileDefects, type DefectsVoicePrefill } from "../mobile/MobileDefects";
import { MobileDailyReport } from "../mobile/MobileDailyReport";
import { MobileSpares, type SparesFilter } from "../mobile/MobileSpares";
import { MobilePlans, type PlansFilter } from "../mobile/MobilePlans";
import { MobileCrew } from "../mobile/MobileCrew";
import { MobileDrills } from "../mobile/MobileDrills";
import { MobileCrewCerts } from "../mobile/MobileCrewCerts";
import { QuickActionFab, type QuickAction } from "./QuickActionFab";
import { VoiceReportSheet } from "./VoiceReportSheet";
import { ProgressFlow } from "./ProgressFlow";
import { useEscapeGuard } from "../lib/escape-guard";

type Tab = "dashboard" | "planes" | "ots" | "defectos" | "diario" | "repuestos" | "copiloto"
  // Sub-vistas accesibles solo desde el dashboard (no van a la barra inferior).
  | "crew" | "drills" | "crewcerts";

// Alias para los tabs accesibles desde dashboard (omite "dashboard" — no
// tiene sentido navegar a sí mismo)
type DashboardTabTarget = Exclude<Tab, "dashboard"> | "panel";

interface TabDef {
  id: Tab;
  label: string;
  Icon: React.FC<{ className?: string }>;
}

const TABS: TabDef[] = [
  { id: "dashboard", label: "Panel",     Icon: LayoutDashboard },
  { id: "planes",    label: "Planes",    Icon: CalendarClock   },
  { id: "ots",       label: "OTs",       Icon: Wrench          },
  { id: "defectos",  label: "Defectos",  Icon: AlertTriangle   },
  { id: "diario",    label: "Diario",    Icon: ClipboardList   },
  { id: "repuestos", label: "Repuestos", Icon: Package         },
  { id: "copiloto",  label: "IA",        Icon: Bot             },
];

export const MobileLayout: React.FC = () => {
  const { tenant, logout }   = useAuth();
  const { vessels, selectedVesselCode, setSelectedVesselCode, selectedVessel } = useVesselContext();
  const [tab, setTab]        = useState<Tab>("dashboard");
  // Filtro inicial para los tabs — lo seta el dashboard cuando navega con foco
  // específico (ej. tocar "Vencidos" → filter "due", "OTs vencidas" → "overdue").
  const [plansFilter, setPlansFilter]     = useState<PlansFilter | undefined>(undefined);
  const [woFilter, setWoFilter]           = useState<WoFilter | undefined>(undefined);
  const [sparesFilter, setSparesFilter]   = useState<SparesFilter | undefined>(undefined);

  // Voice report state — vive en el layout para que cualquier acción (FAB o
  // dentro de Defectos) pueda abrir el mismo sheet.
  const [voiceType, setVoiceType] = useState<"defect" | "near_miss" | null>(null);
  // Prefill que MobileDefects consume al recibirlo (luego notifica consumed).
  const [defectsPrefill, setDefectsPrefill] = useState<DefectsVoicePrefill | null>(null);
  // Registrar avance desde el botón rápido: se elige la OT y se carga ahí mismo.
  const [showProgress, setShowProgress] = useState(false);

  const navigateFromDashboard = (
    target: DashboardTabTarget,
    opts?: { plansFilter?: PlansFilter; woFilter?: WoFilter; sparesFilter?: SparesFilter },
  ) => {
    if (opts?.plansFilter)   setPlansFilter(opts.plansFilter);
    if (opts?.woFilter)      setWoFilter(opts.woFilter);
    if (opts?.sparesFilter)  setSparesFilter(opts.sparesFilter);
    if (target === "panel") setTab("dashboard");
    else setTab(target);
  };

  // Back button del sistema (Android / iOS swipe): si NO estamos en dashboard,
  // volver al dashboard. Los modales/sub-vistas que estén apilados arriba
  // tienen sus propios useEscapeGuard y se cierran primero (LIFO del stack).
  useEscapeGuard({
    enabled: tab !== "dashboard",
    isDirty: false,
    onClose: () => setTab("dashboard"),
  });

  // FAB quick-action: cada acción navega al tab correspondiente.
  const handleQuickAction = (a: QuickAction) => {
    switch (a) {
      case "defect":           setTab("defectos"); break;
      case "near-miss":        setTab("defectos"); break;
      case "defect-voice":     setVoiceType("defect"); break;
      case "near-miss-voice":  setVoiceType("near_miss"); break;
      case "photo":            setShowProgress(true); break;
      case "wo-progress":      setShowProgress(true); break;
    }
  };

  const handleVoiceComplete = (result: { type: "defect" | "near_miss"; fields: DefectsVoicePrefill["fields"] }) => {
    setVoiceType(null);
    setDefectsPrefill({ type: result.type, fields: result.fields });
    setTab("defectos");
  };

  return (
    <CopilotContextProvider>
      <div className="flex flex-col h-screen bg-surface dark:bg-[#0A1A2A] overflow-hidden">

        {/* ── Header ─────────────────────────────────────────────────────────── */}
        <header className="shrink-0 px-4 py-2.5 border-b border-fg/10 flex items-center gap-3 bg-surface dark:bg-[#0D1B2A]">
          <CmsLogo className="w-7 h-7 shrink-0" title={tenant?.name ?? "CMS3.0"} />

          {vessels.length > 1 ? (
            <select
              value={selectedVesselCode ?? ""}
              onChange={e => setSelectedVesselCode(e.target.value || null)}
              className="flex-1 bg-fg/5 border border-fg/10 rounded-lg px-2 py-1 text-xs text-fg focus:outline-none focus:border-accent/50 appearance-none min-w-0"
            >
              <option value="">— Todos —</option>
              {vessels.map(v => (
                <option key={v.code} value={v.code}>{v.name}</option>
              ))}
            </select>
          ) : selectedVessel ? (
            <span className="flex-1 text-xs text-text-industrial/50 truncate">{selectedVessel.name}</span>
          ) : (
            <span className="flex-1" />
          )}

          <button
            type="button"
            onClick={logout}
            className="shrink-0 p-2 -mr-1 text-text-industrial/40 hover:text-fg transition-colors"
            aria-label="Cerrar sesión"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </header>

        {/* ── Content ────────────────────────────────────────────────────────── */}
        <main className="flex-1 overflow-hidden">
          {tab === "dashboard"  && <div className="h-full overflow-y-auto"><MobileDashboard onNavigate={navigateFromDashboard} /></div>}
          {tab === "planes"     && <div className="h-full overflow-hidden flex flex-col"><MobilePlans initialFilter={plansFilter} /></div>}
          {tab === "ots"        && <div className="h-full overflow-hidden flex flex-col"><MobileWorkOrders initialFilter={woFilter} /></div>}
          {tab === "defectos"   && <div className="h-full overflow-hidden flex flex-col"><MobileDefects prefill={defectsPrefill} onPrefillConsumed={() => setDefectsPrefill(null)} /></div>}
          {tab === "diario"     && <div className="h-full overflow-hidden flex flex-col"><MobileDailyReport /></div>}
          {tab === "repuestos"  && <div className="h-full overflow-hidden flex flex-col"><MobileSpares initialFilter={sparesFilter} /></div>}
          {tab === "copiloto"   && <MobileCopilot />}
          {tab === "crew"       && <div className="h-full overflow-hidden flex flex-col"><MobileCrew onBack={() => setTab("dashboard")} /></div>}
          {tab === "drills"     && <div className="h-full overflow-hidden flex flex-col"><MobileDrills initialFilter="overdue" onBack={() => setTab("dashboard")} /></div>}
          {tab === "crewcerts"  && <div className="h-full overflow-hidden flex flex-col"><MobileCrewCerts initialFilter="expired" onBack={() => setTab("dashboard")} /></div>}
        </main>

        {/* ── FAB Acción rápida (sobre el bottom nav) ──────────────────────── */}
        {/* Lo ocultamos en tabs que ya tienen su propio "+"/input flotante para
            no superponer (Defectos, Copiloto) y en las sub-vistas de foco. */}
        {tab !== "defectos" && tab !== "copiloto" && tab !== "crew" && tab !== "drills" && tab !== "crewcerts" && (
          <QuickActionFab onAction={handleQuickAction} />
        )}

        {showProgress && <ProgressFlow onClose={() => setShowProgress(false)} />}

        {/* ── Voice report sheet (compartido layout-wide) ──────────────────── */}
        {voiceType && (
          <VoiceReportSheet
            forcedType={voiceType}
            onClose={() => setVoiceType(null)}
            onComplete={handleVoiceComplete}
          />
        )}

        {/* ── Bottom nav ─────────────────────────────────────────────────────── */}
        <nav className="shrink-0 grid grid-cols-7 border-t border-fg/10 bg-surface dark:bg-[#0D1B2A]">
          {TABS.map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`flex flex-col items-center gap-0.5 py-2.5 transition-colors min-w-0 ${
                tab === id ? "text-accent" : "text-text-industrial/40 hover:text-fg/60"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[9px] font-bold uppercase tracking-wider truncate w-full text-center px-0.5">{label}</span>
            </button>
          ))}
        </nav>

      </div>
    </CopilotContextProvider>
  );
};
