/**
 * Formatted date utility for standardizing date display across the platform.
 * Returns a string in 'DD/MM/YYYY' format or '—' if null/undefined.
 */
export function fmtDate(d?: string | null) {
  if (!d) return "—";
  try {
    // Date-only strings (YYYY-MM-DD) must NOT go through Date() — UTC parsing shifts the day.
    // Parse them directly to avoid timezone-induced off-by-one.
    const dateOnly = /^\d{4}-\d{2}-\d{2}$/.test(d);
    if (dateOnly) {
      const [y, m, day] = d.split("-");
      return `${day}/${m}/${y}`;
    }
    // Prisma @db.Date fields serialize as ISO at UTC midnight (e.g. "2026-04-23T00:00:00.000Z").
    // They carry no time component, so converting them to a local timezone would shift the day
    // (in Argentina, midnight UTC = 21:00 the previous day). Treat them as date-only instead.
    const utcMidnight = /^(\d{4})-(\d{2})-(\d{2})T00:00:00(?:\.000)?Z$/.exec(d);
    if (utcMidnight) {
      return `${utcMidnight[3]}/${utcMidnight[2]}/${utcMidnight[1]}`;
    }
    return new Date(d).toLocaleDateString("es-AR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      timeZone: "America/Argentina/Buenos_Aires",
    });
  } catch {
    return "—";
  }
}

/**
 * Parse a date-only string as LOCAL midnight, not UTC midnight.
 *
 * `new Date("2026-04-28")` is parsed as UTC 00:00 — in UTC-3 that's 21:00 the
 * previous day, which makes date comparisons wrong by one day.
 * Always use this function when comparing a date-only field against today.
 */
export function parseLocalDate(d: string): Date {
  // "YYYY-MM-DD" → local midnight
  const dateOnly = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d);
  if (dateOnly) return new Date(+dateOnly[1], +dateOnly[2] - 1, +dateOnly[3]);
  // Prisma @db.Date serialized as UTC midnight ("...T00:00:00.000Z") — use only the date part
  const utcMidnight = /^(\d{4})-(\d{2})-(\d{2})T00:00:00(?:\.000)?Z$/.exec(d);
  if (utcMidnight) return new Date(+utcMidnight[1], +utcMidnight[2] - 1, +utcMidnight[3]);
  return new Date(d);
}

/**
 * Escapa texto que se va a inyectar como HTML.
 *
 * React escapa solo, pero hay lugares donde armamos HTML a mano y el navegador
 * lo interpreta como tal: los popups y `divIcon` de Leaflet (que por dentro son
 * innerHTML). Ahí, un nombre de buque o un mail con `<img onerror=...>` se
 * ejecuta. Todo dato que venga de la base pasa por acá antes de entrar en esos
 * strings.
 */
export function escapeHtml(value: string): string {
  return String(value).replace(/[&<>"']/g, (c) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c] ?? c
  ));
}

/**
 * Repository-wide rule for filter dropdowns:
 * never use <option value=""> directly in native <select>.
 */
export const FILTER_ALL_VALUE = "__ALL__";

export function toFilterSelectValue(value?: string | null): string {
  const normalized = (value ?? "").trim();
  return normalized || FILTER_ALL_VALUE;
}

export function fromFilterSelectValue(value: string): string {
  return value === FILTER_ALL_VALUE ? "" : value;
}

/**
 * Grupo SFI de un plan (G0…G9): el primer dígito de `sfiGroupNumber`. Un plan
 * puede traer el grupo suelto (0-9) o el código de subgrupo (600 → G6), así que
 * los dos casos se normalizan acá. Devuelve null si el plan no tiene grupo.
 *
 * G0 es el grupo de Inspecciones (incluidas las de Clase).
 */
export function sfiGroupDigit(sfiGroupNumber?: number | null): number | null {
  if (sfiGroupNumber == null) return null;
  const digit = sfiGroupNumber < 10 ? sfiGroupNumber : Math.floor(sfiGroupNumber / 100);
  return digit >= 0 && digit <= 9 ? digit : null;
}

/**
 * Grupo SFI de un EQUIPO a partir de los grupos que declaran sus planes. El
 * grupo lo declara cada plan, no el equipo, y un mismo equipo puede tener
 * tareas cargadas en más de un grupo: se toma el que más se repite (y ante
 * empate, el menor) para que el equipo no se parta en dos lugares de la lista.
 * Devuelve null si ningún plan trae grupo.
 */
export function dominantSfiGroup(sfiGroupNumbers: Array<number | null | undefined>): number | null {
  const counts = new Map<number, number>();
  for (const n of sfiGroupNumbers) {
    const d = sfiGroupDigit(n);
    if (d === null) continue;
    counts.set(d, (counts.get(d) ?? 0) + 1);
  }
  let best: number | null = null;
  let bestCount = 0;
  for (const [d, n] of [...counts.entries()].sort((a, b) => a[0] - b[0])) {
    if (n > bestCount) { best = d; bestCount = n; }
  }
  return best;
}

/** Orden de grupos SFI para listados: G0…G9 y, al final, lo que no tiene grupo. */
export function compareSfiGroup(a: number | null, b: number | null): number {
  if (a === b) return 0;
  if (a === null) return 1;
  if (b === null) return -1;
  return a - b;
}
